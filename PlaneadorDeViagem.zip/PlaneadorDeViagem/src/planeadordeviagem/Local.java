package planeadordeviagem;
/**
 *
 * @author Limeiro
 * @author Etiando
 */
import java.util.ArrayList;
import java.util.Map;

/**
 *
 * @author limeiro
 */
public class Local {

    /**
     *
     */
    protected String nomeLocal;

    /**
     *
     */
    protected Map<String, Integer> hash_map;
    
    ArrayList<PontoDeInteresse> pontosDeInteresse = new ArrayList();
    ArrayList<Local> listaLocais = new ArrayList();

    /**
     *
     * @param nomeLocal
     */
    public Local(String nomeLocal) {
        this.nomeLocal = nomeLocal;
    }
    //PDI == PontoDeInteresse
    
    /**
     *
     * @param PDI
     * @return
     */
    public boolean addNewPDI(PontoDeInteresse PDI){
        if(findPDI(PDI.getNome()) >= 0) {
            System.out.println("Ponto de interesse já existe!");
            return false;
        }
        
        pontosDeInteresse.add(PDI);
        return true;
    }
    
    private int findPDI(PontoDeInteresse PDI){
        return this.pontosDeInteresse.indexOf(PDI);
    }
    
    private int findPDI(String nomePDI){
        for(int i = 0; i < this.pontosDeInteresse.size(); i++){
            PontoDeInteresse PDI = this.pontosDeInteresse.get(i);
            if(PDI.getNome().equals(nomePDI)){
                return i;
            }
        }
        return -1;
    }
    
    /**
     *
     * @return
     */
    public String getNomeLocal() {
        return nomeLocal;
    }

    /**
     *
     * @param nomeLocal
     */
    public void setNomeLocal(String nomeLocal) {
        this.nomeLocal = nomeLocal;
    }

    /**
     *
     * @return
     */
    public ArrayList<PontoDeInteresse> getPontosDeInteresse() {
        return pontosDeInteresse;
    }

    /**
     *
     * @param pontosDeInteresse
     */
    public void setPontosDeInteresse(ArrayList<PontoDeInteresse> pontosDeInteresse) {
        this.pontosDeInteresse = pontosDeInteresse;
    }
    
    /**
     *
     * @param local
     */
    public void addLocal(Local local) {
        listaLocais.add(local);
    }
    
    /**
     *
     * @param newLocal
     * @return
     */
    public int findLocal(String newLocal){
        for(int i = 0; i < listaLocais.size(); i++){
            Local local = listaLocais.get(i);
            if(local.getNomeLocal().equals(newLocal)){
                return i;
            }
        }
      return -1;      
    }

    /**
     *
     * @param hash_map
     */
    public void setHashMap(Map<String, Integer> hash_map){
        this.hash_map = hash_map;
    }
    
    /**
     *
     * @param nomeLocal
     * @return
     */
    public int getCustoViagem(String nomeLocal){
        return hash_map.get(nomeLocal);
    }
    
}
