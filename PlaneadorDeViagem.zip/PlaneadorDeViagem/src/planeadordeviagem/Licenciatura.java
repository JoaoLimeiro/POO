/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package planeadordeviagem;

import java.util.ArrayList;
import java.util.logging.Logger;

/**
 *
 * @author limeiro
 */
public class Licenciatura extends Aluno{

    /**
     *
     * @param montMax
     * @param alunoNome
     * @param nrAluno
     * @param grau
     */
    public Licenciatura(int montMax, String alunoNome, int nrAluno, String grau) {
        super(montMax, alunoNome, nrAluno, grau);
        
    }

    @Override
    public int getMontMax() {
        return montMax;
    }

    /**
     *
     * @param montMax
     */
    @Override
    public void setMontMax(int montMax) {
        this.montMax = montMax;
    }

    /**
     *
     * @return
     */
    @Override
    public String getAlunoNome() {
        return alunoNome;
    }

    /**
     *
     * @param alunoNome
     */
    @Override
    public void setAlunoNome(String alunoNome) {
        this.alunoNome = alunoNome;
    }

    /**
     *
     * @return
     */
    @Override
    public int getNrAluno() {
        return nrAluno;
    }

    /**
     *
     * @param nrAluno
     */
    @Override
    public void setNrAluno(int nrAluno) {
        this.nrAluno = nrAluno;
    }

    /**
     *
     * @return
     */
    @Override
    public String getGrau() {
        return grau;
    }

    /**
     *
     * @param grau
     */
    public void setGrau(String grau) {
        this.grau = grau;
    }
    
    
    
    

}
